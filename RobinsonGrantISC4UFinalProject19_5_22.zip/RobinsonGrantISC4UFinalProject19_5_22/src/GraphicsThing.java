/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.event.KeyListener;
import java.util.ArrayList;

/**
 *
 * @author jarob3698
 */
public class GraphicsThing extends JPanel implements KeyListener {

    int x = 0;
    int y = 0;
    int frameHeight = 0;
    int frameWidth = 0;
    int xChange = 2;
    int yChange = 2;
    boolean notHeld = true;
    boolean wHeld = false;
    boolean aHeld = false;
    boolean sHeld = false;
    boolean dHeld = false;
    boolean bHeld = false;
    /**to do
     *add option to spawn ball with random position and speed
     */
    Ball ball = new Ball(100, 100, 50, 50);
    static boolean pause = false;
    ArrayList<Ball> balls = new ArrayList();

    public GraphicsThing(int w, int h) {
        setFocusable(true);
        requestFocus();
        frameWidth = w;
        frameHeight = h;
        this.addKeyListener(this);
        balls.add(ball);
        x = 0; //start ball at 0
        y = 0;
        //create an actino listener called 'al'
        //it listens for the timer to tick

        ActionListener al = new ActionListener() {
            //when the timer ticks
            public void actionPerformed(ActionEvent ae) {

                for (int i = 0; i < balls.size(); i++) {
                    Ball currentBall = balls.get(i);
                    x = currentBall.getX(); //start ball at 0
                    y = currentBall.getY();

                    if (!pause) {
                        x += currentBall.getXSpeed();
                        y += currentBall.getYSpeed();
                    } else {
                        if (wHeld) {
                            y -= 2;
                        }
                        if (aHeld) {
                            x -= 2;
                        }
                        if (sHeld) {
                            y += 2;
                        }
                        if (dHeld) {
                            x += 2;
                        }
                    }

                    if (x + currentBall.getWidth() >= getWidth()) {
                        currentBall.invertXSpeed();
                        x = getWidth() - currentBall.getWidth();
                    }
                    if (x <= 0) {
                        currentBall.invertXSpeed();
                        x = 0;
                    }
                    if (y + currentBall.getHeight() >= getHeight()) {
                        currentBall.invertYSpeed();
                        y = getHeight() - currentBall.getHeight();
                    }
                    if (y <= 0) {
                        currentBall.invertYSpeed();
                        y = 0;
                    }
                    currentBall.setX(x);
                    currentBall.setY(y);
                    balls.set(i, currentBall);

                }
                repaint(); //redraw the panel

            }
        };
        //make a new timer, and attach it to the action listener
        //the timer fires every 30 ms
        Timer timer = new Timer(30, al);
        //start the timer going
        timer.start();
    }

    private void betterFillOval(int x, int y, int w, int h, Graphics2D g2d) {
        int newX = x - w / 2;
        int newY = y - h / 2;
        g2d.fillOval(newX, newY, w, h);
    }

    private void doDrawing(Graphics g) {
        //the Graphics2D class is the class that handles all the drawing
        //must be casted from older Graphics class in order to have access to some newer methods
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.red);
        //draw a string on the panel
        
        for (int i = 0; i < balls.size(); i++) {
            Ball currentBall = balls.get(i);
            g2d.drawOval(currentBall.getX(), currentBall.getY(), currentBall.getWidth(), currentBall.getHeight());
        }

    }

    @Override
    /**
     * Overrides paintComponent in JPanel class so that we can do our own custom
     * painting
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);//does the necessary work to prepare the panel for drawing
        doDrawing(g); //invoke our custom drawing method
    }

    @Override
    public void keyTyped(KeyEvent ke) {

    }

    @Override
    public void keyPressed(KeyEvent ke) {
        char key = ke.getKeyChar();
        if (key == ' ' && notHeld) {
            notHeld = false;
            System.out.println("test");
            pause = !pause;
        }
        if (key == 'b' && !bHeld) {
            bHeld = true;
            System.out.println("ball created");
            balls.add(new Ball(100, 100, 50, 50));
        }
        if (pause) {
            if (key == 'w' && notHeld) {
                wHeld = true;
            }
            if (key == 'a' && notHeld) {
                aHeld = true;
            }
            if (key == 's' && notHeld) {
                sHeld = true;
            }
            if (key == 'd' && notHeld) {
                dHeld = true;
            }
        }
    }
    boolean wReleased = false;

    @Override
    public void keyReleased(KeyEvent ke) {
        char key = ke.getKeyChar();
        if (key == 'b') {
            bHeld = false;
        }
        if (key == ' ' && !notHeld) {
            notHeld = true;
        }
        if (key == 'w' && notHeld) {
            wHeld = false;
        }
        if (key == 'a' && notHeld) {
            aHeld = false;
        }
        if (key == 's' && notHeld) {
            sHeld = false;
        }
        if (key == 'd' && notHeld) {
            dHeld = false;
        }

    }

    public static void input() {
        if (pause) {
            pause = false;
        } else {
            pause = true;
        }
    }

}
