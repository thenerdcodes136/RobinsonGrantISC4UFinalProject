/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author jarob3698
 */
public class Ball {
    public int x = 0;
    public int y = 0;
    public int height = 0;
    public int width = 0;
    public int xSpeed = 2;
    public int ySpeed = 2;
    public Ball(int xPos, int yPos, int width1, int height1){
        x = xPos;
        y = yPos;
        height = height1;
        width  = width1;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public int getHeight(){
        return height;
    }
    public int getWidth(){
        return width;
    }
    public void setHeight(int h){
        height = h;
    }
    public void setWidth(int w){
        width = w;
    }
    public void setX(int xPos){
        x = xPos;
    }
    public void setY(int yPos){
        y = yPos;
    }
    public int getYSpeed(){
        return ySpeed;
    }
    public int getXSpeed(){
        return xSpeed;
    }
    public void setYSpeed(int speedY){
        ySpeed = speedY;
    }
    public void setXSpeed(int speedX){
        xSpeed = speedX;
    }
    public void invertXSpeed(){
        xSpeed *= -1;
    }
    public void invertYSpeed(){
        ySpeed *= -1;
    }
}
