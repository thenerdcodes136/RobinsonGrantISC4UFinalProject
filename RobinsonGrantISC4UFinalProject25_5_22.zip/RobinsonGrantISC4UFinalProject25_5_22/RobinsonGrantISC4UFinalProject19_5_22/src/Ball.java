
import static java.lang.Math.abs;
import static java.lang.Math.atan;
import static java.lang.Math.sqrt;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author jarob3698
 */
public class Ball {

    private double x = 0;
    private double y = 0;
    private double height = 0;
    private double width = 0;
    private double xSpeed = 0;
    private double ySpeed = 0;
    private double angle = 0;
    private double speed = 0;
    public Ball(double xPos, double yPos, double width1, double height1) {
        x = xPos;
        y = yPos;
        height = height1;
        width = width1;
        refreshAngle();
        refreshSpeed();
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getHeight() {
        return height;
    }

    public double getWidth() {
        return width;
    }

    public void setHeight(double h) {
        height = h;
    }

    public void setWidth(double w) {
        width = w;
    }

    public void setX(double xPos) {
        x = xPos;
    }

    public void setY(double yPos) {
        y = yPos;
    }

    public double getYSpeed() {
        return ySpeed;
    }

    public double getXSpeed() {
        return xSpeed;
    }

    public void setYSpeed(double speedY) {
        ySpeed = speedY;
        refreshAngle();
        refreshSpeed();
    }

    public void setXSpeed(double speedX) {
        xSpeed = speedX;
        refreshAngle();
        refreshSpeed();
    }

    public void invertXSpeed() {
        xSpeed *= -1;
        refreshAngle();
        refreshSpeed();
    }

    public void invertYSpeed() {
        ySpeed *= -1;
        refreshAngle();
        refreshSpeed();
    }

    public double getAngle() {
        refreshAngle();
        return angle;
    }
    
    public void refreshAngle() {
        angle = atan(abs(ySpeed) / abs(xSpeed));
        if (xSpeed > 0 && ySpeed < 0) {
            angle = 360 - angle;
        }
        if (xSpeed < 0 && ySpeed > 0) {
            angle = 180 - angle;
        }
        if (xSpeed < 0 && ySpeed < 0) {
            angle = 180 + angle;
        }
    }
    public void refreshSpeed(){
        speed = sqrt((xSpeed * xSpeed) + (ySpeed * ySpeed));
    }
    
    public double getSpeed(){
        refreshSpeed();
        return speed;
    }
}
