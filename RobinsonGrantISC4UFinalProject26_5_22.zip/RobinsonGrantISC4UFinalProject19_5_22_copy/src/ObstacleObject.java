



/**
 * Obstacle class 5/25/2022 Click
 * nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to
 * change this license Click
 * nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this
 * template
 */
/**
 *
 * @author jarob3698
 */
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.Area;
import java.awt.Graphics;
public class ObstacleObject{
    private Polygon p1;
    private int xPoints[];
    private int yPoints[];
    private Color colour;
    private boolean collide;
    private int sides;
    private Area area;
    public ObstacleObject() {
        sides = 0;
        xPoints = new int[0];
        yPoints = new int[0];
        colour = Color.red;
        collide = false;
        
    }
    
    public ObstacleObject(int x[], int y[], Color c,  int s) {
        sides = s;
        xPoints = x;
        yPoints = y;
        colour = c;
        p1 = new Polygon(xPoints, yPoints, s);
        area = new Area(p1);
    }

    public boolean getCollision(Polygon p) {
        Area area1 = new Area(p);
        area = new Area(p1);
        area1.intersect(area);
        return !(area.isEmpty());
    }
    public Polygon getPolygon(){
        return p1;
    }
    public void setX(int i, int x) {
        xPoints[i] = x;
    }

    public void setY(int i, int y) {
        yPoints[i] = y;
    }

    public int getX(int i) {
        return xPoints[i];
    }

    public int getY(int i) {
        return yPoints[i];
    }
    
    public void setColour(Color c) {
        colour = c;
    }

    public Color getColour() {
        return colour;
    }
    public int getSides(){
        return sides;
    }
    public boolean equals(ObstacleObject o) {
        boolean test = true;
        if (sides != o.getSides()){
            test = false;
        }else{
            for (int i = 0; i < sides; i++) {
                if(xPoints[i] != o.getX(i)){
                    test = false;
                }
                if(yPoints[i] != o.getY(i)){
                    test = false;
                }
            }
        }
        return test;
    }

    public String toString() {
        String str = "";
        str += "Colour: " + colour + ", Collide: " + collide + ", Coordinates:";
        for (int i = 0; i < sides; i++) {
            str += " (" + xPoints[i] + "," + yPoints[i] + ")";
        }
        return str;
    }
    public void draw(Graphics2D g2d){
        g2d.setColor(colour);
        g2d.drawPolygon(xPoints, yPoints, sides);
    }
}
